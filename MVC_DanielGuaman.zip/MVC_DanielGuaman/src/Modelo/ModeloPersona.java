package Modelo;

import ConexionPG.ConexionBD;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ModeloPersona extends Persona{

    ConexionPG.ConexionBD con = new ConexionBD();

    public ModeloPersona() {
    }

    public boolean InsertarPersona() {

        String sql = "INSERT INTO public.persona("
                + "idpersona, nombres, apellidos, fecha_nac, telefono, sexo, sueldo, cupo, correo)"
                + "VALUES ('" + getIdPersona() + "', '" + getNombrePersona() + "', '" + getApellidoPersona() + "', '" + getFecha_nac() + "', "
                + "'" + getTelefono() + "', '" + getSexo() + "', '" + getSueldo() + "', " + getCupo() + ", '" + getCorreo() + "');";
        return con.CRUD(sql);

    }

    public boolean Validar(){
        
        try {
            boolean validar = false;
            int count = 0;            
            
            String sql = "select count(idpersona) from persona where idpersona = '" + getIdPersona() + "'";
            ResultSet res = con.Consultas(sql);
            while (res.next()) {
                
                count = res.getInt("count");
            }
            if (count == 0) {
                
                validar = true;
            }
            res.close();
            return validar;
            
        } catch (SQLException ex) {
            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public boolean EliminarPersona() {

        String sql = "DELETE FROM public.persona\n"
                + "WHERE idpersona = '" + getIdPersona() + "';";
        return con.CRUD(sql);

    }

    public boolean ModficarPersona() {

        String sql = "UPDATE public.persona "
                + "SET nombres='" + getNombrePersona() + "', apellidos='" + getApellidoPersona() + "', "
                + "fecha_nac='" + getFecha_nac() + "', telefono='" + getTelefono() + "', sexo='" + getSexo() + "', sueldo=" + getSueldo() + ", "
                + "cupo=" + getCupo() + ", correo='" + getCorreo() + "',foto='" + getFoto() + "' "
                + "WHERE idpersona ='" + getIdPersona() + "';";
        return con.CRUD(sql);

    }

    public List<Persona> ListaPersonas() {

        try {
            String sql = "SELECT * FROM public.persona";
            ResultSet res = con.Consultas(sql);
            List<Persona> per = new ArrayList<>();

            while (res.next()) {

                Persona miper = new Persona();

                miper.setApellidoPersona(res.getString("apellidos"));
                miper.setCorreo(res.getString("correo"));
                miper.setCupo(res.getInt("cupo"));
                miper.setFecha_nac(res.getDate("fecha_nac"));
                miper.setIdPersona(res.getString("idpersona"));
                miper.setNombrePersona(res.getString("nombres"));
                miper.setSexo(res.getString("sexo"));
                miper.setSueldo(res.getDouble("sueldo"));
                miper.setTelefono(res.getString("telefono"));
                miper.setFoto(res.getString("foto"));

                per.add(miper);
            }
            res.close();
            return per;
        } catch (SQLException ex) {
            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

}
