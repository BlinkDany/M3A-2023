package Modelo;

import java.sql.Date;

public class Persona {
    
    private String IdPersona;
    private String nombrePersona;
    private String apellidoPersona;
    private String telefono;
    private String sexo;
    private String correo;
    private double sueldo;
    private int cupo;
    private Date fecha_nac;
    private String foto;

    public Persona() {
    }

    public Persona(String IdPersona, String nombrePersona, String apellidoPersona, String telefono, String sexo, String correo, double sueldo, int cupo, Date fecha_nac, String foto) {
        this.IdPersona = IdPersona;
        this.nombrePersona = nombrePersona;
        this.apellidoPersona = apellidoPersona;
        this.telefono = telefono;
        this.sexo = sexo;
        this.correo = correo;
        this.sueldo = sueldo;
        this.cupo = cupo;
        this.fecha_nac = fecha_nac;
        this.foto = foto;
    }

    public String getIdPersona() {
        return IdPersona;
    }

    public void setIdPersona(String IdPersona) {
        this.IdPersona = IdPersona;
    }

    public String getNombrePersona() {
        return nombrePersona;
    }

    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }

    public String getApellidoPersona() {
        return apellidoPersona;
    }

    public void setApellidoPersona(String apellidoPersona) {
        this.apellidoPersona = apellidoPersona;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public int getCupo() {
        return cupo;
    }

    public void setCupo(int cupo) {
        this.cupo = cupo;
    }

    public Date getFecha_nac() {
        return fecha_nac;
    }

    public void setFecha_nac(Date fecha_nac) {
        this.fecha_nac = fecha_nac;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
    
}
