package Controlador;

import Modelo.ModeloPersona;
import Modelo.Persona;
import Vista.VPersona;
import static com.sun.javafx.tk.Toolkit.getToolkit;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

public class ControladorPersona {

    private ModeloPersona modelper;
    private VPersona visper;

    public ControladorPersona() {
    }

    public ControladorPersona(ModeloPersona modelper, VPersona visper) {
        this.modelper = modelper;
        this.visper = visper;
        visper.setVisible(true);
    }

    public void Iniciar() {

        visper.setLocationRelativeTo(null);
        visper.setTitle("Persona");
        visper.getTxtRuta().setVisible(false);
        visper.getBtnEliminar().addActionListener(l -> Eliminar());
        visper.getBtnLimpiar().addActionListener(l -> Limpiar());
        visper.getBtnBuscar().addActionListener(l -> Buscar());
        visper.getBtnFoto().addActionListener(l -> Foto());
        visper.getBtnCancelar().addActionListener(l -> visper.getDialogPer().dispose());
        visper.getBtnRegistrar().addActionListener(l -> abrirDialog("Crear"));
        visper.getBtnModificar().addActionListener(l -> {

            if (visper.getTblPersona().getSelectedRow() == -1) {

                JOptionPane.showMessageDialog(visper, "Seleccione al cliente que desee modificar", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                abrirDialog("Editar");
            }
        });
        visper.getTxtSueldo().addKeyListener(new KeyAdapter() {

            @Override
            public void keyTyped(KeyEvent evt) {

                Validaciones.Decimales(evt, visper.getTxtSueldo().getText());
            }

        });
        visper.getTxtCupos().addKeyListener(new KeyAdapter() {

            @Override
            public void keyTyped(KeyEvent evt) {

                Validaciones.Enteros(evt, visper.getTxtCupos().getText());
            }
        });
        visper.getTxtCedula().addKeyListener(new KeyAdapter() {

            @Override
            public void keyTyped(KeyEvent evt) {

                Validaciones.ValidarCedulas(evt, visper.getTxtCedula().getText());
            }
        });
        visper.getTxtTelf().addKeyListener(new KeyAdapter() {

            @Override
            public void keyTyped(KeyEvent evt) {

                Validaciones.ValidarTelefonos(evt, visper.getTxtCedula().getText());
            }
        });
        MostrarDatos();
        //dialogo
        visper.getBtnRes().addActionListener(l -> CrearEditarPersona());
    }

    private void abrirDialog(String ce) {

        visper.getDialogPer().setLocationRelativeTo(visper);
        visper.getDialogPer().setSize(930, 638);
        visper.getDialogPer().setTitle(ce);
        if (visper.getDialogPer().getTitle().equals("Crear")) {

            visper.getBtnRes().setText("Registrar");
            Limpiar();
            visper.getTxtCedula().setEnabled(true);
        } else {

            visper.getBtnRes().setText("Modificar");
            LlenarDatos();
            visper.getTxtCedula().setEnabled(false);

        }
        visper.getDialogPer().setVisible(true);
    }

    public String Sex() {

        String x = "";

        if (visper.getRbtnFeme().isSelected()) {

            x = "Femenino";
        }
        if (visper.getRbtnMas().isSelected()) {

            x = "Masculino";
        }
        if (visper.getRbtnOtros().isSelected()) {

            x = "Otro";
        }
        return x;
    }

    public void CrearEditarPersona() {

        if (visper.getDialogPer().getTitle().equals("Crear")) {

            if (visper.getTxtApellidos().getText().isEmpty() || visper.getTxtCedula().getText().isEmpty() || visper.getTxtRuta().getText().isEmpty() || visper.getTxtSueldo().getText().isEmpty()
                    || visper.getTxtTelf().getText().isEmpty() || visper.getTxtCorreo().getText().isEmpty() || visper.getTxtCupos().getText().isEmpty() || visper.getTxtFechaNac().getDate() == null
                    || visper.getTxtNombres().getText().isEmpty() || visper.getTxtCorreo().getText().isEmpty()) {

                JOptionPane.showMessageDialog(null, "Faltan campos por llenar", "Error", JOptionPane.ERROR_MESSAGE);
            } else {

                modelper.setIdPersona(visper.getTxtCedula().getText());

                if (modelper.Validar()) {

                    if (Validaciones.correos(visper.getTxtCorreo().getText())) {

                        modelper.setApellidoPersona(visper.getTxtApellidos().getText());
                        modelper.setCorreo(visper.getTxtCorreo().getText());
                        modelper.setCupo(Integer.valueOf(visper.getTxtCupos().getText()));
                        modelper.setFecha_nac(new java.sql.Date(visper.getTxtFechaNac().getDate().getTime()));
                        modelper.setFoto(visper.getTxtRuta().getText());
                        modelper.setNombrePersona(visper.getTxtNombres().getText());
                        modelper.setSexo(Sex());
                        modelper.setSueldo(Double.valueOf(visper.getTxtSueldo().getText()));
                        modelper.setTelefono(visper.getTxtTelf().getText());

                        if (modelper.InsertarPersona()) {
                            JOptionPane.showMessageDialog(null, "Se ha registrado exito", "Advertencia", JOptionPane.INFORMATION_MESSAGE);
                            visper.getDialogPer().dispose();
                            MostrarDatos();
                        } else {

                            JOptionPane.showMessageDialog(null, "No se ha podido registrar por un error en la base de datos", "Advertencia", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        
                        JOptionPane.showMessageDialog(visper, "Ingrese un correo valido", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } else {

                    JOptionPane.showMessageDialog(visper, "La cedula ya existe", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }

        } else if (visper.getDialogPer().getTitle().equals("Editar")) {

            int x = JOptionPane.showConfirmDialog(visper, "Esta seguro de modificar esta informacion?", "Advertencia", JOptionPane.YES_NO_OPTION);
            if (x == 0) {

                modelper.setIdPersona(visper.getTxtCedula().getText());

                modelper.setCorreo(visper.getTxtCorreo().getText());
                modelper.setApellidoPersona(visper.getTxtApellidos().getText());
                modelper.setCupo(Integer.valueOf(visper.getTxtCupos().getText()));
                modelper.setFecha_nac(new java.sql.Date(visper.getTxtFechaNac().getDate().getTime()));
                modelper.setNombrePersona(visper.getTxtNombres().getText());
                modelper.setSexo(Sex());
                modelper.setSueldo(Double.valueOf(visper.getTxtSueldo().getText()));
                modelper.setTelefono(visper.getTxtTelf().getText());
                modelper.setFoto(visper.getTxtRuta().getText());

                if (modelper.ModficarPersona()) {

                    JOptionPane.showMessageDialog(visper, "Se ha modificado con exito", "Advertencia", JOptionPane.INFORMATION_MESSAGE);
                    MostrarDatos();

                }
            }
        }

    }

    public void MostrarDatos() {

        DefaultTableModel tabla = (DefaultTableModel) visper.getTblPersona().getModel();
        tabla.setNumRows(0);

        List<Persona> listper = modelper.ListaPersonas();
        listper.stream().forEach(p -> {

            String fecha_actual = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy"));
            String fecha_nac = p.getFecha_nac().toString().substring(0, 4);
            int edad = Integer.parseInt(fecha_actual) - Integer.parseInt(fecha_nac);

            Object[] datos = {p.getIdPersona(), p.getNombrePersona(), p.getApellidoPersona(), edad};
            tabla.addRow(datos);
        });
    }

    public void Buscar() {

        if (visper.getTxtBuscador().getText().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Ingrese un numero de cedula", "Error", JOptionPane.ERROR_MESSAGE);
        } else {

            DefaultTableModel tabla = (DefaultTableModel) visper.getTblPersona().getModel();
            tabla.setNumRows(0);

            List<Persona> listper = modelper.ListaPersonas();
            listper.stream().forEach(p -> {

                if (visper.getTxtBuscador().getText().equals(p.getIdPersona())) {

                    String fecha_actual = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy"));
                    String fecha_nac = p.getFecha_nac().toString().substring(0, 4);
                    int edad = Integer.parseInt(fecha_actual) - Integer.parseInt(fecha_nac);

                    Object[] datos = {p.getIdPersona(), p.getNombrePersona(), p.getApellidoPersona(), edad};
                    tabla.addRow(datos);

                }
            });
        }

    }

    public void LlenarDatos() {

        List<Persona> listper = modelper.ListaPersonas();
        listper.stream().forEach(p -> {

            if (visper.getTblPersona().getValueAt(visper.getTblPersona().getSelectedRow(), 0).equals(p.getIdPersona())) {

                visper.getTxtApellidos().setText(p.getApellidoPersona());
                visper.getTxtCedula().setText(p.getIdPersona());
                visper.getTxtCorreo().setText(p.getCorreo());
                visper.getTxtCupos().setText(String.valueOf(p.getCupo()));
                visper.getTxtFechaNac().setDate(p.getFecha_nac());
                visper.getTxtNombres().setText(p.getNombrePersona());
                visper.getTxtSueldo().setText(String.valueOf(p.getSueldo()));
                visper.getTxtTelf().setText(p.getTelefono());
                visper.getTxtRuta().setText(p.getFoto());

                ImageIcon miImagen = new ImageIcon(visper.getTxtRuta().getText());
                Image foto = miImagen.getImage();
                foto = foto.getScaledInstance(145, 145, Image.SCALE_SMOOTH);
                visper.getLblFoto().setIcon(new ImageIcon(foto));

                if (p.getSexo().equals("Masculino")) {

                    visper.getRbtnMas().setSelected(true);
                }
                if (p.getSexo().equals("Femenino")) {

                    visper.getRbtnFeme().setSelected(true);
                }
                if (p.getSexo().equals("Otro")) {

                    visper.getRbtnOtros().setSelected(true);
                }

            }

        });

    }

    public void Eliminar() {

        int x = JOptionPane.showConfirmDialog(null, "Esta seguro de eliminar esta informacion?", "Advertencia", JOptionPane.YES_NO_OPTION);

        if (x == 0) {

            modelper.setIdPersona(visper.getTblPersona().getValueAt(visper.getTblPersona().getSelectedRow(), 0).toString());

            if (modelper.EliminarPersona()) {

                JOptionPane.showMessageDialog(null, "Se elimino con exito", "Advertencia", JOptionPane.INFORMATION_MESSAGE);
                MostrarDatos();

            }
        }
    }

    public void Limpiar() {

        visper.getTxtApellidos().setText("");
        visper.getTxtBuscador().setText("");
        visper.getTxtCedula().setText("");
        visper.getTxtCorreo().setText("");
        visper.getTxtCupos().setText("");
        visper.getTxtFechaNac().setDate(null);
        visper.getTxtNombres().setText("");
        visper.getTxtSueldo().setText("");
        visper.getTxtTelf().setText("");
        visper.getTxtRuta().setText("");
        visper.getBtnGroup1().clearSelection();
        visper.getLblFoto().setIcon(null);
        MostrarDatos();
    }

    public void Foto() {

        JFileChooser file = new JFileChooser();
        file.setAcceptAllFileFilterUsed(false);
        FileNameExtensionFilter filtrado = new FileNameExtensionFilter("JGP, PNG, & GIF", "jpg", "png", "gif");
        file.setFileFilter(filtrado);
        file.setDialogTitle("Abrir Archivo");

        File Ruta = new File("C:\\Users\\blink\\Pictures");
        file.setCurrentDirectory(Ruta);

        int res = file.showOpenDialog(visper);
        if (res == JFileChooser.APPROVE_OPTION) {

            File archivo = file.getSelectedFile();
            visper.getTxtRuta().setText(String.valueOf(archivo));
            ImageIcon miImagen = new ImageIcon(visper.getTxtRuta().getText());
            Image foto = miImagen.getImage();
            foto = foto.getScaledInstance(visper.getLblFoto().getWidth(), visper.getLblFoto().getHeight(), Image.SCALE_SMOOTH);
            visper.getLblFoto().setIcon(new ImageIcon(foto));
        }

    }

}
