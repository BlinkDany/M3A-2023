package mvc_danielguaman;

import Controlador.ControladorPersona;
import Modelo.ModeloPersona;
import Modelo.Persona;
import Vista.VPersona;

public class MVC_main {
    
    public static void main (String[] args){
        
        Modelo.ModeloPersona model = new ModeloPersona();
        VPersona vper = new VPersona();
        Persona per = new Persona();
        
        Controlador.ControladorPersona ctrl = new ControladorPersona(model, vper);
        ctrl.Iniciar();
        
    }
    
}
